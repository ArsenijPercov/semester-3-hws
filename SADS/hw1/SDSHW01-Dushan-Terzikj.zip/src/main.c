#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "rpn.h"

int main(int argc, char* argv[]){
    
    char *expr = malloc(sizeof(char)*255);
    for(int i = 1; i < argc; i++){
        strcat(expr, argv[i]);
        if(i < argc-1)
            strcat(expr, " ");
    }

    char *result = malloc(sizeof(char)*255);
    int rc = rpn_eval_expr(expr, &result);

    printf("%s\n", result);

    return 0;
}