/*
 * pnmhide/src/hide.c --
 */

#include "image.h"
#include "hide.h"

int im_encode(image_t *im, char *msg) {
    return 0;
}

int im_decode(image_t *im, char *buffer, size_t size) {
    return 0;
}
