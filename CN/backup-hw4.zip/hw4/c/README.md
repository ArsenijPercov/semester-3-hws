Changes in f2, f3, e1 and e4 .conf files.

You can ping or traceroute yourself. For some examples check a4-ping-b2.txt and
a4-traceroute-b2.txt.