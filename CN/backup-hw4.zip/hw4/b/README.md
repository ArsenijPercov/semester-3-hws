As an example, I took down e2-eth2 interface. I used the following formula for that:

```sh
    mininet> e2 ip link set e2-eth2 down
```

b2-traceroute-b3-before.txt shows the hops needed for a message to get from b2 to b3
BEFORE the link was taken down.

b2-traceroute-b3-after.txt shows the hops needed for a message to get from b2 to b3
AFTER the link was taken down.