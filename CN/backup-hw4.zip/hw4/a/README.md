Usage:
[host] ping6 [host_ipv6_address]

First it will show several ICMP messages from the router that there is no path, but that
is only the part where the routers exchange LSAs with information about other routers.
The closest router will inform the host that there is no route to the receiving host,
but once it finds a route, the exchange of ICMP will start. Check b1-ping6-b3.txt for example.