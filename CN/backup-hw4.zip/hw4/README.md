The whole repository is diveded into parts a, b, c, d, and e, all corresponding for the parts
on the homework sheet. Please read the README.md in each of the parts for instructions on how to
use the mininet script. Check the *.conf files for grading.

Working/Discussion Group: Brian Sherif, Fezi Manana, Dragi Kamov, Jasmine Dayinta.